//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


//: Homework Calculator - variables and integers, adding and subtracting - needs interface to put in values

print("Adding and Subtracting is pretty tought stuff. Get some help with this handy dandy Homework Calculator")

//: adding
let firstPlusNumber = Int()
let secondPlusNumber = Int()
let plusAnswer = firstPlusNumber + secondPlusNumber
print(plusAnswer)

//: subtracting
let firstSubtractNumber = Int()
let secondSubtractNumber = Int()
let subtractAnswer = firstSubtractNumber + secondSubtractNumber
print(subtractAnswer)



//: Surf Shop Owner - variables, integers, reading, counting - needs interface to put in values (change to bike shop)
print("When owning a surf shop, there is lots to keep track of. Use this tool to help the store owner keep track of how much stuff they have in the shop.")
let wetsuites = Int()
let surfBoards = Int()
let booties = Int()
print("She has \(wetsuites) wetsuits, \(surfBoards) surf boards, and \(booties) booties")

print("She wants to add a new item to the store. Help her add ten towels to her list.")
var inventory = ["wetsuits", "surf boards", "booties"]
inventory.append("towels")
print(inventory)
print("Now note how many towels there are:")
let towels = Int()


//: ClassDojo - conditionals, variables, counting, numbers up to 100 - "" - video of classroom working, at the bottom pictures of students and + and - next to each face. Player is the teacher and goes around to give each student points when they are on task or do something kind.
let student = String()
let score = Int()
if score > 75 {
    print("Nice job \(student)!")
} else {
        print("Keep trying \(student) and you'll get it next time.")
}


